# %%
#download necessary packages/check if they are installed
# %pip install yfinance pandas numpy scikit-learn plotly PyPortfolioOpt streamlit 

# %%
# %pip install matplotlib 

# %%
######  Fetching Portfolio Data
import pandas as pd
import yfinance as yf
import numpy as np
import matplotlib.pyplot as plt
import pypfopt as pyp 

#ingest portfolio data, using tabs as separators
portfolio = pd.read_csv("portfolio.csv", sep='\t')
#turn to dataframe
portfolio = pd.DataFrame(portfolio)
#inspect data
portfolio.head()





# %%
#inspect columns
portfolio.columns
#fix column names remove whitespaces
portfolio.columns = portfolio.columns.str.strip()
#reinspect columns 
portfolio.columns 

# %%
######## Fetching Historical Data ########

tickers =  portfolio['ticker'].unique().tolist() 
print(tickers)


def fetch_historical_data(tickers, period='2y'):
    """
    Fetch adjusted close prices from Yahoo Finance.
    Returns: pd.DataFrame (dates x tickers) of daily returns
    """
    try:
        df = yf.download(tickers, period=period, auto_adjust=True)['Close']
        returns = df.pct_change().dropna()
        return returns
    except Exception as e:
        print(f"Error fetching historical data: {e}")
        return None


tickers_data = fetch_historical_data(tickers)
tickers_data.head() 



# %%
#Compute Portfolio Stats

def compute_stats(tickers_data):
    """
    Compute annualized expected returns (μ) and covariance matrix (Σ).
    
    Args:
        returns: pd.DataFrame of daily pct changes
    
    Returns:
        mu (np.array): Annualized expected return per asset
        S (np.array): Annualized covariance matrix
    """
    mu = tickers_data.mean()*252 #252 trading days
    from sklearn.covariance import LedoitWolf
    lw = LedoitWolf()
    S_daily = lw.fit(tickers_data).covariance_

    S = pd.DataFrame(S_daily*252, index=tickers_data.columns, columns=tickers_data.columns)
    return mu, S


mu, S = compute_stats(tickers_data)
print(mu, S)


# %%
##visualize covariance

#S is annualized covariance
plt.figure(figsize=(10,8))


plt.imshow(S, cmap ='viridis')

#add labels
plt.colorbar(label = 'Covariance(Annualized Variance/Covariance)')

plt.xticks(range(len(S.columns)), S.columns, rotation = 45)
plt.yticks(range(len(S.columns)), S.columns, rotation = 45)

for i in range(len(S.columns)):
    for j in range(len(S.columns)):
        plt.text(j, i,f"{S.iloc[i,j]:.4f}", ha ="center", va = "center", color = "white" if S.iloc[i,j] < 0.02 else "black")

plt.title("Asset covariance matrix (risks and relationships)")
plt.show()

# %%
### Optimize Portfolio (minimize risk)

from pypfopt import EfficientFrontier

# Maximize Sharpe ratio using SLSQP optimizer.
    
#     Args:
#         mu: Expected returns (annualized)
#         S: Covariance matrix
#         risk_free_rate: Risk-free rate (default: 2% / Canadian GIC rate)
    
#     Returns:
#         weights: dict {ticker: weight}
#         sharpe: Sharpe ratio
#         ret, vol: Expected return, volatility of optimized portfolio



def portfolio_optimization(mu, S, risk_free_rate=0.02): #conservative baseline risk to beat):
    ef = EfficientFrontier(mu, S, weight_bounds=(0, 1))
    weights = ef.max_sharpe(risk_free_rate=risk_free_rate)
    ret, vol, sharpe = ef.portfolio_performance()
    
    return weights, sharpe, ret, vol



# %%
#### making the optimizer more robust


def robust_optimize(mu, S, regularization_gamma=0.01):
    """
    Add L2 regularization to prevent extreme weight concentrations.
    Higher gamma → more diversification, lower max weights.
    """
    ef = EfficientFrontier(mu, S, weight_bounds=(0.05, 0.5))  # Min 5%, Max 50%
    
    # Optional: Add shrinkage to mu/S estimates (data is noisy)
    mu_shrink = 0.8 * mu + 0.2 * np.mean(mu)  # Pull extreme returns toward mean
    
    from pypfopt import objective_functions
    ef.add_objective(objective_functions.L2_reg, gamma=regularization_gamma)


    weights = ef.max_sharpe()
    return weights
    

# %%
def calculate_rebalance_trades(current_holdings, target_weights, current_prices, drift_threshold=0.05):
    """
    Compare current weights to target; suggest trades if drift > threshold.
    
    Args:
        current_holdings: dict {ticker: {'shares': int, 'cost_basis': float}}
        target_weights: dict {ticker: target_weight_float}
        current_prices: dict {ticker: price_float}
        drift_threshold: 5% default (rebalance if weight drift > 5%)
    
    Returns:
        trades: list of dicts {ticker, action, shares, reason, est_gain}
    """
    trades = []
    
    # Calculate the total portfolio value using only tickers we have current prices for
    portfolio_value = sum(
        current_holdings[t]['shares'] * current_prices[t] 
        for t in current_holdings if t in current_prices
    )
    
    for ticker in current_holdings:
        # Skip tickers we don't have pricing for
        if ticker not in current_prices:
            continue
        
        current_value = current_holdings[ticker]['shares'] * current_prices[ticker]
        current_weight = current_value / portfolio_value if portfolio_value > 0 else 0
        
        # Get target weight (default to 0 if not in target portfolio)
        target_weight = target_weights.get(ticker, 0)
        
        # Calculate the drift
        weight_diff = target_weight - current_weight
        
        # Check against the drift threshold
        if abs(weight_diff) > drift_threshold:
            
            # Find the new target value in dollars
            target_value = portfolio_value * target_weight
            value_to_trade = target_value - current_value
            
            # Determine exactly how many shares to buy or sell
            shares_to_trade = int(value_to_trade / current_prices[ticker])
            
            # If the trade ends up being less than 1 share, skip it
            if shares_to_trade == 0:
                continue
                
            action = 'BUY' if shares_to_trade > 0 else 'SELL'
            abs_shares = abs(shares_to_trade)
            
            # Estimate capital gains/losses (only applicable for SELLs)
            est_gain = 0
            if action == 'SELL':
                est_gain = (current_prices[ticker] - current_holdings[ticker]['cost_basis']) * abs_shares
                
            trades.append({
                'ticker': ticker,
                'action': action,
                'shares': abs_shares,
                'reason': f"Drift {abs(weight_diff)*100:.1f}% > {drift_threshold*100:.1f}% threshold",
                'est_gain': round(est_gain, 2),
                'current_weight': round(current_weight, 4),
                'target_weight': round(target_weight, 4)
            })
            
    return trades

# %%
# Convert your portfolio DataFrame into a dictionary for the rebalancer
current_holdings = {}

for index, row in portfolio.iterrows():
    current_holdings[row['ticker']] = {
        'shares': row['shares'],
        'cost_basis': row['avg_cost']  # Mapping your avg_cost column!
    }

# Ensure we have our optimal weights from the optimizer
weights = robust_optimize(mu, S)

# Get the most recent prices from your yfinance data (the last row)
current_prices = tickers_data.iloc[-1].to_dict()

# Call the function!
trades = calculate_rebalance_trades(
    current_holdings=current_holdings, 
    target_weights=weights, 
    current_prices=current_prices,
    drift_threshold=0.05
)

# Print out the results nicely
import pandas as pd
print(pd.DataFrame(trades))
